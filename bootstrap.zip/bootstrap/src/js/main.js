import '../scss/styles.scss';
import '../scss/vars.scss';
// Импортируйте наш пользовательский CSS
import '../scss/styles.scss';

// Импортируйте весь JS Bootstrap
import * as bootstrap from 'bootstrap';
